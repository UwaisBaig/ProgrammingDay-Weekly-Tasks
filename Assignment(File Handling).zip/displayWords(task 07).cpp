﻿#include <iostream>
#include <fstream>
#include <sstream>
using namespace std;

void displayWords(string fileName) {
    ifstream file(fileName);

    if (!file.is_open()) {
        cout << "Error opening file!" << endl;
        return;
    }

    string line;
    while (getline(file, line)) {
        stringstream ss(line);
        string word;

        while (ss >> word) {
            if (word.length() < 4)
                cout << word << endl;
        }
    }

    file.close();
}

int main() {
    displayWords("Task7.txt");
    return 0;
}

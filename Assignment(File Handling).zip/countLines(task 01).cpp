﻿

#include <iostream>
#include<fstream>
#include<string>

using namespace std;
int countLines(string fileName)
{
	fstream file(fileName);
	string line;
	int count = 0;
	{
		if(file.is_open() )
			while (getline(file, line))
			{
				count++;

			}
		else {
			cout << "unable to put output" << endl;
		}
	}
}
int main()
{
	int totalines = countLines("Task 1.txt");
	
	return 0;
}

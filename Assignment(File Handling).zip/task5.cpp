#include <iostream>
#include <fstream>
using namespace std;
int main(){
    string line;
    fstream file;
    file.open("example.txt",ios::in);
    getline(file,line);
    file.close();
    cout<<"The line in the file: "<<endl<<line;
}
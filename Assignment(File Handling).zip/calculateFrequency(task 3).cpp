﻿#include <iostream>
#include <fstream>
#include <string>
using namespace std;

// Function prototype
int countCharacters(string fileName);

int main() {
    string fileName = "Task2.txt";

    int total = countCharacters(fileName);

    cout << "Total number of characters: " << total << endl;

    return 0;
}

// Function definition
int countCharacters(string fileName) {
    ifstream file(fileName);
    string line;
    int count = 0;

    if (!file.is_open()) {
        cout << "Error! Cannot open file." << endl;
        return 0;
    }

    // Read file line by line
    while (getline(file, line)) {
        count += line.length();   // Count characters in each line
    }

    file.close();
    return count;
}

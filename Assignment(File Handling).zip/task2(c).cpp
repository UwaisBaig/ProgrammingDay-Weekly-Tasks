#include <iostream>
#include <fstream>
using namespace std;
int main(){
    char character;
    cout<<"Enter a character: ";
    cin>>character;
    fstream file;
    file.open("character.txt",ios::out);
    file<<character;
    file.close();
    return 0;
}
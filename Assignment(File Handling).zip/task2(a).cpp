#include <fstream>
#include <iostream>
using namespace std;

int main(){
    int num;
    cout<<"Enter an integer: ";
    cin>>num;
    fstream file;
    file.open("integer.txt",ios::out);
    file<<num;
    file.close();
    return 0;
}

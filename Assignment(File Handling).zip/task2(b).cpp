#include <iostream>
#include <fstream>
using namespace std;
int main(){
    double decimalNum;
    cout<<"Enter a decimal number: ";
    cin>>decimalNum;
    fstream file;
    file.open("decimal.txt",ios::out);
    file<<decimalNum;
    file.close();
    return 0;
}
﻿#include <iostream>
#include <fstream>
#include <sstream>
using namespace std;

const int MAX_USERS = 100;

string usernames[MAX_USERS];
string passwords[MAX_USERS];
string roles[MAX_USERS];
int userCount = 0;

void loadUsers() {
    ifstream file("users.txt");
    if (!file.is_open()) return;

    string line;
    while (getline(file, line)) {
        stringstream ss(line);
        string username, password, role;

        getline(ss, username, ',');
        getline(ss, password, ',');
        getline(ss, role, ',');

        usernames[userCount] = username;
        passwords[userCount] = password;
        roles[userCount] = role;
        userCount++;
    }
    file.close();
}

void saveUser(string username, string password, string role) {
    ofstream file("users.txt", ios::app);
    file << username << "," << password << "," << role << endl;
    file.close();
}

void signUp() {
    string username, password, role;

    cout << "Enter Username: ";
    cin >> username;
    cout << "Enter Password: ";
    cin >> password;
    cout << "Enter Role (admin/user): ";
    cin >> role;

    usernames[userCount] = username;
    passwords[userCount] = password;
    roles[userCount] = role;
    userCount++;

    saveUser(username, password, role);

    cout << "Signup Successful!\n";
}

void signIn() {
    string username, password;

    cout << "Enter Username: ";
    cin >> username;
    cout << "Enter Password: ";
    cin >> password;

    for (int i = 0; i < userCount; i++) {
        if (usernames[i] == username && passwords[i] == password) {
            cout << "Login Successful! Welcome " << roles[i] << endl;
            return;
        }
    }
    cout << "Invalid Username or Password!\n";
}

int main() {
    loadUsers();

    int choice;
    cout << "1. Sign Up\n2. Sign In\nEnter choice: ";
    cin >> choice;

    if (choice == 1)
        signUp();
    else if (choice == 2)
        signIn();
    else
        cout << "Invalid Option!\n";
}
#include <iostream>
#include <fstream>
using namespace std;
int main(){
    int num;
    fstream file;
    file.open("example.txt",ios::in);
    file>>num;
    file.close();
    cout<<"the integer in the file: "<<num;
}
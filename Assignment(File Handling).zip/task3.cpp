#include <iostream>
#include <fstream>
using namespace std;
int main(){
    string name;
    fstream file;
    file.open("example.ext",ios::in);
    file>>name;
    file.close();
    cout<<"The name in the file" <<name;
}
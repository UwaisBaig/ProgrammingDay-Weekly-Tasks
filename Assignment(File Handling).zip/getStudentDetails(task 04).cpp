﻿#include <iostream>
#include <fstream>
using namespace std;

// Function Prototypes
void getStudentDetails(string names[], int ages[], float matricMarks[],
    float fscMarks[], float ecatMarks[], int size, int& count);

void saveToFile(string names[], int ages[], float matricMarks[],
    float fscMarks[], float ecatMarks[], int count, string fileName);

int main()
{
    const int size = 100;
    string names[size];
    int ages[size];
    float matricMarks[size], fscMarks[size], ecatMarks[size];
    int count = 0;

    getStudentDetails(names, ages, matricMarks, fscMarks, ecatMarks, size, count);
    saveToFile(names, ages, matricMarks, fscMarks, ecatMarks, count, "student.txt");

    cout << "Data saved to student.txt\n";
    return 0;
}

// -----------------------------
void getStudentDetails(string names[], int ages[], float matricMarks[],
    float fscMarks[], float ecatMarks[], int size, int& count)
{
    string more = "Yes";

    while (more == "Yes" || more == "yes")
    {
        cout << "\nEnter Name: ";
        cin.ignore();
        getline(cin, names[count]);

        cout << "Enter Age: ";
        cin >> ages[count];

        cout << "Enter Matric Marks: ";
        cin >> matricMarks[count];

        cout << "Enter FSC Marks: ";
        cin >> fscMarks[count];

        cout << "Enter ECAT Marks: ";
        cin >> ecatMarks[count];

        count++;

        cout << "Add another student? (Yes/No): ";
        cin >> more;
    }
}

// -----------------------------
void saveToFile(string names[], int ages[], float matricMarks[],
    float fscMarks[], float ecatMarks[], int count, string fileName)
{
    ofstream file(fileName);

    for (int i = 0; i < count; i++)
    {
        file << names[i] << ", "
            << ages[i] << ", "
            << matricMarks[i] << ", "
            << fscMarks[i] << ", "
            << ecatMarks[i] << endl;
    }
}
#include <fstream>
using namespace std;
fstream file;
file.open("example.ext",ios::in);
file<<"This is the sample text";
file.close();
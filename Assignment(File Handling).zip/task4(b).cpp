#include <iostream>
#include <fstream>
using namespace std;
int main(){
    double dnum;
    fstream file;
    file.open("example.txt",ios::in);
    file>>dnum;
    file.close();
    cout<<"the decimal number in the file: "<<dnum;
}
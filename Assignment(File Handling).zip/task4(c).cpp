#include <iostream>
#include <fstream>
using namespace std;
int main(){
    char character;
    fstream file;
    file.open("example.txt",ios::in);
    file>>character;
    file.close();
    cout<<"the character in the file: "<<character;
}